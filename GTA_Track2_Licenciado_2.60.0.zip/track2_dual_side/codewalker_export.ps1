param([Parameter(Mandatory=$true)][string]$Request,[Parameter(Mandatory=$true)][string]$Result)
$ErrorActionPreference='Stop'
function Get-Track2Hash([byte[]]$Bytes) {
    $algorithm=[Security.Cryptography.SHA256]::Create()
    try { return ([BitConverter]::ToString($algorithm.ComputeHash($Bytes))).Replace('-','').ToLowerInvariant() }
    finally { $algorithm.Dispose() }
}
try {
    $job=Get-Content -LiteralPath $Request -Raw -Encoding UTF8 | ConvertFrom-Json
    $folder=[IO.Path]::GetFullPath($job.codewalker)
    foreach ($name in @('SharpDX.dll','SharpDX.Mathematics.dll','CodeWalker.Core.dll')) {
        $dll=Join-Path $folder $name
        if (!(Test-Path -LiteralPath $dll)) { throw "Dependencia CodeWalker ausente: $dll" }
        [void][Reflection.Assembly]::LoadFrom($dll)
    }
    $names=@('vehicle_track2_emissive','vehicle_track2_emissive.sps')+@($job.shader_names)
    $strings=Join-Path $folder 'strings.txt'
    if (Test-Path -LiteralPath $strings) { $names+=@(Get-Content -LiteralPath $strings -Encoding UTF8) }
    foreach ($name in $names) {
        if ($null -eq $name) { continue }
        $text=$name.Trim()
        if ($text.Length -eq 0 -or $text.StartsWith('//')) { continue }
        [void][CodeWalker.GameFiles.JenkIndex]::Ensure($text)
        if (!$text.EndsWith('.sps')) { [void][CodeWalker.GameFiles.JenkIndex]::Ensure($text+'.sps') }
    }
    $out=[IO.Path]::GetFullPath($job.output)
    [void][IO.Directory]::CreateDirectory($out)
    $files=@()
    foreach ($source in $job.files) {
        $path=[IO.Path]::GetFullPath($source)
        $data=[IO.File]::ReadAllBytes($path)
        if ($data.Length -lt 16 -or [Text.Encoding]::ASCII.GetString($data,0,4) -ne 'RSC7') { throw "YFT RSC7 invalido: $path" }
        $version=[BitConverter]::ToUInt32($data,4)
        if ($version -notin @(162,171)) { throw "Versao YFT nao suportada pelo fluxo: $version" }
        [CodeWalker.GameFiles.RpfManager]::IsGen9=($version -eq 171)
        $yft=New-Object CodeWalker.GameFiles.YftFile
        $yft.Name=[IO.Path]::GetFileName($path)
        $yft.Load($data)
        if ($null -eq $yft.Fragment) { throw "CodeWalker nao carregou o Fragment: $path" }
        $name=[IO.Path]::GetFileName($path)
        $textures=Join-Path $out ([IO.Path]::GetFileNameWithoutExtension($name))
        [void][IO.Directory]::CreateDirectory($textures)
        $xml=[CodeWalker.GameFiles.YftXml]::GetXml($yft,$textures)
        $destination=Join-Path $out ($name+'.xml')
        [IO.File]::WriteAllText($destination,$xml,(New-Object Text.UTF8Encoding($false)))
        $files+=@{source=$path;xml=$destination;version=$version;source_sha256=(Get-Track2Hash $data)}
    }
    $hasher=[Security.Cryptography.SHA256]::Create()
    try { $digest=([BitConverter]::ToString($hasher.ComputeHash([IO.File]::ReadAllBytes((Join-Path $folder 'CodeWalker.Core.dll'))))).Replace('-','').ToLowerInvariant() }
    finally { $hasher.Dispose() }
    $answer=@{ok=$true;files=$files;engine='CodeWalker.Core/YftXml';assembly_sha256=$digest}
    [IO.File]::WriteAllText($Result,($answer|ConvertTo-Json -Depth 8),(New-Object Text.UTF8Encoding($false)))
    exit 0
} catch {
    $answer=@{ok=$false;error=$_.Exception.Message}
    [IO.File]::WriteAllText($Result,($answer|ConvertTo-Json -Depth 8),(New-Object Text.UTF8Encoding($false)))
    exit 1
}
