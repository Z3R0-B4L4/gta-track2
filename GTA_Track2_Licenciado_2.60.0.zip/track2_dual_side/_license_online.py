# SPDX-License-Identifier: GPL-3.0-or-later
"""One-use activation codes and offline signed receipts, without hardware IDs."""
import hashlib,json,re
from ._license_protocol import canonical,b64,unb64,key_id,release_aad,LicenseError

RECEIPT_DOMAIN=b'Track2 receipt v3\x00'
REQUEST_DOMAIN=b'Track2 installation request v3\x00'


def policy(days=30,lifetime=False):
    if type(lifetime) is not bool:raise LicenseError('Lifetime deve ser verdadeiro ou falso.')
    if lifetime:return None,True
    if type(days) is not int or not 1<=days<=36500:raise LicenseError('Use de 1 a 36500 dias ou lifetime.')
    return days,False


def install_id(public):return hashlib.sha256(unb64(public)).hexdigest()


def new_installation():
    from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
    private=Ed25519PrivateKey.generate()
    return {'schema':3,'private_key':b64(private.private_bytes_raw()),'public_key':b64(private.public_key().public_bytes_raw())}


def sign_request(action,installation,data):
    from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
    body=dict(data,public_key=installation['public_key'])
    body['signature']=b64(Ed25519PrivateKey.from_private_bytes(unb64(installation['private_key'])).sign(REQUEST_DOMAIN+action.encode()+b'\x00'+canonical(body)))
    return body


def verify_request(action,body):
    from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey
    from cryptography.exceptions import InvalidSignature
    try:
        public=unb64(body['public_key']);sig=unb64(body['signature']);data={k:v for k,v in body.items() if k!='signature'}
        if len(public)!=32 or not re.fullmatch('[0-9a-f]{32}',body['request_id']):raise ValueError()
        Ed25519PublicKey.from_public_bytes(public).verify(sig,REQUEST_DOMAIN+action.encode()+b'\x00'+canonical(data))
        return install_id(body['public_key'])
    except (KeyError,ValueError,TypeError,InvalidSignature) as exc:raise LicenseError('Assinatura da instalação inválida.') from exc


def sign_receipt(secret,grant):
    from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
    days,lifetime=policy(grant['validity_days'],bool(grant['lifetime']))
    payload={k:secret[k] for k in ('schema','product','version','release_id','key_id','aes_key')}
    payload.update(license_schema=3,license_id=grant['id'],installation_id=grant['installation_id'],
        activated_at=grant['activated_at'],issued_at=grant['updated_at'],revision=grant['revision'],
        validity_days=days,lifetime=lifetime,customer=grant['customer'],
        expires_at=None if lifetime else grant['activated_at']+days*86400)
    raw=canonical(payload)
    sig=Ed25519PrivateKey.from_private_bytes(unb64(secret['private_key'])).sign(RECEIPT_DOMAIN+raw)
    return 'T2R1.'+b64(raw)+'.'+b64(sig)


def verify_receipt(receipt,config,installation):
    if isinstance(receipt,str) and receipt.startswith('T2D1.'):
        try:from ._license_dev import verify_dev
        except ImportError:from .dev_tokens import verify_dev
        return verify_dev(receipt,config)
    from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey
    from cryptography.exceptions import InvalidSignature
    try:
        if not isinstance(receipt,str) or len(receipt)>8192:raise ValueError()
        prefix,body,signature=receipt.strip().split('.')
        if prefix!='T2R1':raise ValueError()
        public=unb64(config['public_key'])
        if key_id(public)!=config['key_id']:raise ValueError()
        raw=unb64(body);Ed25519PublicKey.from_public_bytes(public).verify(unb64(signature),RECEIPT_DOMAIN+raw)
        claims=json.loads(raw)
        if canonical(claims)!=raw:raise ValueError()
        for field in ('schema','product','version','release_id','key_id'):
            if claims[field]!=config[field]:raise LicenseError('Licença de outra versão. Ative com um token desta versão.')
        if claims['license_schema']!=3 or claims['installation_id']!=install_id(installation['public_key']):
            raise LicenseError('Licença pertence a outra instalação. Ela não usa HWID ou UUID.')
        if not re.fullmatch('[0-9a-f]{32}',claims['license_id']):raise ValueError()
        for f in ('activated_at','issued_at','revision'):
            if type(claims[f]) is not int or claims[f]<1:raise ValueError()
        days,lifetime=policy(claims['validity_days'],claims['lifetime'])
        expected=None if lifetime else claims['activated_at']+days*86400
        if claims['expires_at']!=expected or len(unb64(claims['aes_key']))!=32:raise ValueError()
        return claims
    except LicenseError:raise
    except (KeyError,ValueError,TypeError,InvalidSignature) as exc:
        raise LicenseError('Licença assinada inválida ou alterada.') from exc


def open_payload(receipt,config,installation,cipher):
    from cryptography.hazmat.primitives.ciphers.aead import AESGCM
    from cryptography.exceptions import InvalidTag
    claims=verify_receipt(receipt,config,installation)
    if hashlib.sha256(cipher).hexdigest()!=config['cipher_sha256']:raise LicenseError('Pacote criptografado alterado. Reinstale o ZIP original.')
    try:clear=AESGCM(unb64(claims['aes_key'])).decrypt(unb64(config['nonce']),cipher,release_aad(config))
    except (ValueError,InvalidTag) as exc:raise LicenseError('Falha de autenticidade AES-GCM.') from exc
    return claims,clear
