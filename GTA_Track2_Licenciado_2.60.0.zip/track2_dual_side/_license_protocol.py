# SPDX-License-Identifier: GPL-3.0-or-later
"""Versioned, canonical, signed licenses; no issuer secrets in the verifier."""
import base64
import hashlib
import json
import re
import time

PRODUCT = 'gta-track2'
DOMAIN = b'GTA-TRACK2-LICENSE-V1\x00'


class LicenseError(ValueError):
    pass


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=True).encode('ascii')


def b64(data):
    return base64.urlsafe_b64encode(data).rstrip(b'=').decode('ascii')


def unb64(value):
    if not isinstance(value, str) or not re.fullmatch(r'[A-Za-z0-9_-]+', value):
        raise LicenseError('Codificação do token inválida.')
    try:
        data = base64.b64decode(value + '=' * (-len(value) % 4), altchars=b'-_', validate=True)
    except (ValueError, TypeError) as exc:
        raise LicenseError('Codificação do token inválida.') from exc
    if b64(data) != value:
        raise LicenseError('Token não está no formato canônico.')
    return data


def hwid_code(value):
    text = value.strip().upper()
    if not re.fullmatch(r'T2H1-[0-9A-F]{64}', text):
        raise LicenseError('HWID inválido. Copie o código T2H1 exibido no addon.')
    return text


def key_id(public_key):
    return hashlib.sha256(public_key).hexdigest()[:32]


def release_aad(config):
    return canonical({k: config[k] for k in ('schema', 'product', 'version', 'release_id', 'key_id', 'public_key')})


def license_id(release_id, hwid):
    return hashlib.sha256(canonical([PRODUCT, release_id, hwid_code(hwid)])).hexdigest()


def issue_token(secret, hwid, customer='', validity_days=30, lifetime=False, revision=None):
    from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
    if type(lifetime) is not bool:
        raise LicenseError('Lifetime deve ser verdadeiro ou falso.')
    if not lifetime and (type(validity_days) is not int or not 1 <= validity_days <= 36500):
        raise LicenseError('Informe uma validade entre 1 e 36500 dias ou selecione lifetime.')
    if revision is None:revision=time.time_ns()
    if type(revision) is not int or revision < 1:
        raise LicenseError('Revisão da licença inválida.')
    payload = {
        'schema': 1, 'product': PRODUCT, 'version': secret['version'],
        'release_id': secret['release_id'], 'key_id': secret['key_id'],
        'hwid': hwid_code(hwid), 'customer': str(customer).strip()[:160],
        'issued_at': int(time.time()), 'aes_key': secret['aes_key'],
        'license_schema': 2, 'license_id': license_id(secret['release_id'], hwid),
        'revision': revision, 'lifetime': lifetime,
        'validity_days': None if lifetime else validity_days,
    }
    raw = canonical(payload)
    signature = Ed25519PrivateKey.from_private_bytes(unb64(secret['private_key'])).sign(DOMAIN + raw)
    return 'T2L1.' + b64(raw) + '.' + b64(signature)


def verify_token(token, config, hwid):
    from cryptography.exceptions import InvalidSignature
    from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey
    if not isinstance(token, str) or len(token) > 8192:
        raise LicenseError('Token inválido ou muito grande.')
    try:
        prefix, body, sig = token.strip().split('.')
        if prefix != 'T2L1':
            raise LicenseError('Use um token T2L1 emitido pelo gerador.')
        raw, signature = unb64(body), unb64(sig)
        public = unb64(config['public_key'])
        if len(public) != 32 or key_id(public) != config['key_id']:
            raise LicenseError('Configuração pública da versão inválida.')
        Ed25519PublicKey.from_public_bytes(public).verify(signature, DOMAIN + raw)
        payload = json.loads(raw)
        if not isinstance(payload, dict) or canonical(payload) != raw:
            raise LicenseError('Conteúdo do token inválido.')
        for field in ('schema', 'product', 'version', 'release_id', 'key_id'):
            if payload.get(field) != config[field]:
                raise LicenseError('Token pertence a outra versão. Solicite um token para esta atualização.')
        if payload.get('hwid') != hwid_code(hwid):
            raise LicenseError('Token pertence a outra placa-mãe. Envie o HWID deste computador ao emissor.')
        if payload.get('license_schema') != 2:
            raise LicenseError('Token antigo sem política de validade. Emita um token atualizado.')
        if payload.get('license_id') != license_id(config['release_id'], hwid):
            raise LicenseError('Identificador da licença inválido.')
        if type(payload.get('revision')) is not int or payload['revision'] < 1:
            raise LicenseError('Revisão da licença inválida.')
        if type(payload.get('lifetime')) is not bool:
            raise LicenseError('Tipo de validade inválido.')
        days=payload.get('validity_days')
        if (payload['lifetime'] and days is not None) or (not payload['lifetime'] and (type(days) is not int or not 1 <= days <= 36500)):
            raise LicenseError('Prazo da licença inválido.')
        if type(payload.get('issued_at')) is not int or payload['issued_at'] < 1:
            raise LicenseError('Data de emissão inválida.')
        key = unb64(payload['aes_key'])
        if len(key) != 32:
            raise LicenseError('A licença não contém uma chave AES-256 válida.')
        return payload, key
    except LicenseError:
        raise
    except InvalidSignature as exc:
        raise LicenseError('Assinatura inválida. O token foi alterado ou não foi emitido para este pacote.') from exc
    except (ValueError, KeyError, TypeError, AttributeError) as exc:
        raise LicenseError('Token ou configuração da licença inválido.') from exc


def revise_token(secret, previous_token, validity_days=30, lifetime=False):
    """An offline policy change is a new signed revision of the same license."""
    try:
        hwid=json.loads(unb64(previous_token.strip().split('.')[1]))['hwid']
    except (ValueError, IndexError, KeyError, TypeError) as exc:
        raise LicenseError('Cole um token existente válido para alterar sua validade.') from exc
    claims,_=verify_token(previous_token,secret['public_config'],hwid)
    return issue_token(secret,hwid,claims.get('customer',''),validity_days,lifetime,
                       revision=max(time.time_ns(),claims['revision']+1))


def decrypt_payload(token, config, hwid, ciphertext):
    from cryptography.exceptions import InvalidTag
    from cryptography.hazmat.primitives.ciphers.aead import AESGCM
    payload, key = verify_token(token, config, hwid)
    if hashlib.sha256(ciphertext).hexdigest() != config['cipher_sha256']:
        raise LicenseError('Pacote criptografado alterado ou incompleto. Reinstale a versão original.')
    try:
        clear = AESGCM(key).decrypt(unb64(config['nonce']), ciphertext, release_aad(config))
    except (InvalidTag, ValueError) as exc:
        raise LicenseError('Falha de autenticidade AES-GCM. Token e pacote precisam pertencer à mesma versão.') from exc
    return payload, clear
