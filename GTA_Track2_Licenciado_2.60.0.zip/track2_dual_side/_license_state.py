# SPDX-License-Identifier: GPL-3.0-or-later
import copy,json,time
from pathlib import Path
from ._license_protocol import LicenseError
from ._license_vault import protect,atomic_write


def load(path):
    if not Path(path).is_file():return {'schema':3,'licenses':{}}
    try:
        data=json.loads(protect(Path(path).read_bytes(),decrypt=True))
        if data['schema']!=3 or not isinstance(data['licenses'],dict):raise ValueError()
        return data
    except (ValueError,OSError,KeyError,TypeError) as exc:raise LicenseError('Histórico local inválido. Restaure as configurações ou contate o emissor.') from exc


def save(path,data):atomic_write(path,protect(json.dumps(data,sort_keys=True).encode('utf-8')))


def assess(claims,history,now=None):
    now=int(time.time() if now is None else now);result=copy.deepcopy(history)
    row=result['licenses'].get(claims['license_id'])
    if not claims['lifetime'] and now+300<claims['issued_at']:raise LicenseError('O relógio está anterior à emissão da licença. Corrija a data e hora do Windows.')
    if row:
        if claims['revision']<row['revision']:raise LicenseError('Licença substituída por uma revisão mais recente. Clique em Atualizar licença.')
        if not claims['lifetime'] and now+300<row['last_seen']:raise LicenseError('O relógio do Windows retrocedeu. Corrija a data e hora.')
        # Dev claims use the signed release-envelope issue date. New releases
        # deliberately rotate that date, while the fixed lifetime token keeps
        # its original local history. Normal grants must keep activation dates.
        dev_lifetime=claims.get('license_type')=='dev' and claims['lifetime'] and claims['expires_at'] is None
        if row['activated_at']!=claims['activated_at'] and not dev_lifetime:raise LicenseError('A data original de ativação não corresponde ao histórico.')
    else:row={'activated_at':claims['activated_at'],'last_seen':now,'revision':claims['revision']}
    row.update(last_seen=max(now,row['last_seen']),revision=claims['revision'])
    result['licenses'][claims['license_id']]=row
    active=claims['expires_at'] is None or now<claims['expires_at']
    return result,active
