param([string]$CodeWalker,[string]$Source,[string]$Destination,[switch]$ToXml)
$ErrorActionPreference='Stop'
foreach ($name in @('SharpDX.dll','SharpDX.Mathematics.dll','CodeWalker.Core.dll')) {
    [void][Reflection.Assembly]::LoadFrom((Join-Path $CodeWalker $name))
}
if ($ToXml) {
    [byte[]]$data=[IO.File]::ReadAllBytes($Source)
    if ($data.Length -lt 16 -or [Text.Encoding]::ASCII.GetString($data,0,4) -ne 'RSC7' -or [BitConverter]::ToUInt32($data,4) -ne 46) {
        throw 'Esperado YCD Legacy RSC7, versao 46.'
    }
    $entry=[CodeWalker.GameFiles.RpfFile]::CreateResourceFileEntry([ref]$data,46)
    $entry.Name=[IO.Path]::GetFileName($Source)
    $file=New-Object CodeWalker.GameFiles.YcdFile
    $file.Load([CodeWalker.GameFiles.ResourceBuilder]::Decompress($data),$entry)
    if ($null -eq $file.ClipDictionary) { throw 'CodeWalker nao conseguiu ler o YCD.' }
    [IO.File]::WriteAllText($Destination,[CodeWalker.GameFiles.YcdXml]::GetXml($file))
} else {
    $file=[CodeWalker.GameFiles.XmlYcd]::GetYcd([IO.File]::ReadAllText($Source))
    $file.InitDictionaries()
    if ($null -eq $file.ClipDictionary -or $file.ClipMap.Count -eq 0 -or $file.AnimMap.Count -eq 0) {
        throw 'O dicionario precisa ter clipes e animacoes.'
    }
    [IO.File]::WriteAllBytes($Destination,$file.Save())
}
