# SPDX-License-Identifier: GPL-3.0-or-later
"""Owner vault and cached activation protected by Windows current-user DPAPI."""
import ctypes
from ctypes import wintypes
import json
import os
from pathlib import Path
import tempfile


class Blob(ctypes.Structure):
    _fields_ = [('size', wintypes.DWORD), ('data', ctypes.POINTER(ctypes.c_ubyte))]


def protect(data, decrypt=False):
    if os.name != 'nt':
        raise OSError('O cofre usa a proteção de dados do Windows (DPAPI).')
    crypt = ctypes.WinDLL('crypt32', use_last_error=True)
    kernel = ctypes.WinDLL('kernel32', use_last_error=True)
    source = (ctypes.c_ubyte * len(data)).from_buffer_copy(data)
    inp, output = Blob(len(data), source), Blob()
    kernel.LocalFree.argtypes = [ctypes.c_void_p]
    kernel.LocalFree.restype = ctypes.c_void_p
    function = crypt.CryptUnprotectData if decrypt else crypt.CryptProtectData
    function.argtypes = [ctypes.POINTER(Blob), ctypes.c_void_p, ctypes.POINTER(Blob), ctypes.c_void_p, ctypes.c_void_p, wintypes.DWORD, ctypes.POINTER(Blob)]
    function.restype = wintypes.BOOL
    if not function(ctypes.byref(inp), None, None, None, None, 1, ctypes.byref(output)):
        raise OSError('Não foi possível abrir/proteger o cofre neste usuário do Windows. Código ' + str(ctypes.get_last_error()))
    try:
        return ctypes.string_at(output.data, output.size)
    finally:
        kernel.LocalFree(output.data)


def atomic_write(path, data):
    path = Path(path); path.parent.mkdir(parents=True, exist_ok=True)
    temporary = None
    try:
        with tempfile.NamedTemporaryFile(dir=path.parent, delete=False) as stream:
            temporary = Path(stream.name); stream.write(data)
        os.replace(temporary, path)
    finally:
        if temporary and temporary.exists():
            temporary.unlink()


def save_vault(path, secret):
    path = Path(path)
    if path.exists():
        raise ValueError('Já existe um cofre para esta versão. Use outra versão; as chaves existentes não serão sobrescritas.')
    atomic_write(path, protect(json.dumps(secret, sort_keys=True).encode('utf-8')))


def load_vault(path):
    return json.loads(protect(Path(path).read_bytes(), decrypt=True))


def default_vault_dir():
    return Path(os.environ.get('LOCALAPPDATA', Path.home())) / 'Track2Issuer' / 'private_releases'
