# SPDX-License-Identifier: GPL-3.0-or-later
"""One online redemption, signed offline license; no HWID/UUID reads."""
import functools,importlib,json,sys,time,uuid
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import bpy
from bpy.props import StringProperty
from ._license_protocol import b64,unb64,LicenseError
from ._license_online import new_installation,sign_request,open_payload,verify_receipt
from ._license_vault import protect,atomic_write
from ._license_loader import MemoryModules
from ._license_state import load as load_history,save as save_history,assess
from ._license_http import request,server_url
from . import _github_update

_folder=Path(__file__).parent
_config=json.loads((_folder/'release.json').read_text(encoding='utf-8'))
_core=None;_finder=None;_claims=None;_session=None;_registered=False;_authorized=False
_message='Insira um código de ativação de uso único.'
_last_write=0.;_session_wall=0.;_session_mono=0.
_receipt_verified=False;_future=None;_executor=None;_last_check=0.


def cache_dir():return Path(bpy.utils.user_resource('CONFIG',create=True))/'track2_licenses'
def state_file():return cache_dir()/(_config['release_id']+'.installation')
def history_file():return cache_dir()/(_config['release_id']+'.history')


def _save_session():atomic_write(state_file(),protect(json.dumps(_session,sort_keys=True).encode('utf-8')))


def _load_session():
    global _session
    if _session is not None:return _session
    if state_file().is_file():
        try:_session=json.loads(protect(state_file().read_bytes(),decrypt=True))
        except (ValueError,OSError) as exc:raise LicenseError('A instalação local não pode ser aberta neste usuário do Windows.') from exc
    else:
        # Older signed receipts cannot be opened with this release's public
        # key. Their IDs are only hints for an online request signed with the
        # old random installation key; the service authenticates that grant.
        candidates=[]
        for path in state_file().parent.glob('*.installation'):
            try:
                previous=json.loads(protect(path.read_bytes(),decrypt=True))
                if str(previous.get('receipt','')).startswith('T2D1.'):
                    claims=verify_receipt(previous['receipt'],_config,previous['installation'])
                    candidate=dict(installation=previous['installation'],receipt=previous['receipt'],pending=None,
                        url=_config.get('activation_url') or previous.get('url',''),pending_update=False,
                        validated_release=_config['release_id'])
                    candidates.append((2,0,path.stat().st_mtime,candidate));continue
                claims=json.loads(unb64(previous['receipt'].split('.')[1]))
                if claims.get('product')!=_config['product'] or claims.get('release_id')==_config['release_id']:continue
                if len(claims.get('license_id',''))!=32:continue
                candidate=dict(installation=previous['installation'],receipt=previous['receipt'],pending=None,
                    url=_config.get('activation_url') or previous.get('url',''),pending_update=True)
                candidates.append((bool(claims.get('lifetime')),claims.get('expires_at') or 0,path.stat().st_mtime,candidate))
            except (OSError,ValueError,KeyError,TypeError,AttributeError,IndexError):continue
        _session=max(candidates,key=lambda item:item[:3])[3] if candidates else dict(installation=new_installation(),receipt=None,pending=None,url=_config.get('activation_url',''))
    return _session


def _status():
    if not _claims:return 'Ativação necessária'
    if _claims.get('license_type')=='dev':return f"Dev {_claims['dev_slot']:02d}/10 · lifetime offline"
    if _claims['lifetime']:return 'Lifetime · sem vencimento' if _authorized else 'Lifetime · validação necessária'
    from datetime import datetime
    date=datetime.fromtimestamp(_claims['expires_at']).astimezone().strftime('%d/%m/%Y %H:%M')
    return ('Vencimento: ' if time.time()<_claims['expires_at'] else 'Expirada em ')+date


def check_access(persist=False):
    global _authorized,_message,_last_write,_last_check
    if not _claims or not _receipt_verified:_authorized=False;return False
    if _claims['lifetime']:return _authorized
    if not persist and time.monotonic()-_last_check<.5 and (_claims['expires_at'] is None or time.time()<_claims['expires_at']):return _authorized
    _last_check=time.monotonic()
    try:
        if _session_mono and time.time()+300<_session_wall+(time.monotonic()-_session_mono):
            raise LicenseError('O relógio do Windows retrocedeu durante o uso. Corrija a data e hora.')
        history,active=assess(_claims,load_history(history_file()))
        if persist or time.monotonic()-_last_write>60:
            save_history(history_file(),history);_last_write=time.monotonic()
        _authorized=active;_message=_status() if active else 'Licença expirada. Solicite nova validade ao emissor e clique em Atualizar licença.'
    except Exception as exc:_authorized=False;_message=str(exc)
    return _authorized


def _require():
    if not check_access():raise LicenseError(_message)


def _wrap_core(core):
    def protect_operator(method,has_event):
        # Blender validates bytecode argument counts, not inspect.signature.
        if has_event:
            @functools.wraps(method)
            def guarded(self,context,event):
                if not check_access():self.report({'ERROR'},_message);return {'CANCELLED'}
                return method(self,context,event)
        else:
            @functools.wraps(method)
            def guarded(self,context):
                if not check_access():self.report({'ERROR'},_message);return {'CANCELLED'}
                return method(self,context)
        return guarded
    def protect_draw(method):
        @functools.wraps(method)
        def guarded(self,context):
            if not check_access():self.layout.label(text='Licença expirada. Use o painel Licença.',icon='LOCKED');return
            return method(self,context)
        return guarded
    for cls in core.CLASSES:
        if issubclass(cls,bpy.types.Operator):
            for method in ('execute','invoke','modal'):
                if method in cls.__dict__:setattr(cls,method,protect_operator(getattr(cls,method),method!='execute'))
        elif issubclass(cls,(bpy.types.Panel,bpy.types.AddonPreferences)) and 'draw' in cls.__dict__:
            cls.draw=protect_draw(cls.draw)


def apply_receipt(receipt,persist=True,online=False):
    global _claims,_authorized,_core,_finder,_message,_session_wall,_session_mono,_receipt_verified
    session=_load_session()
    dev=isinstance(receipt,str) and receipt.startswith('T2D1.')
    if not online and not dev and (session.get('validated_release')!=_config['release_id'] or session.get('pending_update')):
        raise LicenseError('Esta atualização precisa ser validada online uma vez antes do uso offline.')
    claims,plaintext=open_payload(receipt,_config,session['installation'],(_folder/'payload.aes').read_bytes())
    history,active=assess(claims,load_history(history_file()))
    # A signed shortening/expiry also replaces the old cached receipt.
    save_history(history_file(),history)
    session['receipt']=receipt;session['pending']=None
    if online or dev:session['validated_release']=_config['release_id'];session['pending_update']=False
    if persist:_save_session()
    _claims=claims;_authorized=active;_receipt_verified=True;_session_wall=time.time();_session_mono=time.monotonic()
    if active and _core is None:
        finder=MemoryModules(__package__,_folder,plaintext);sys.meta_path.insert(0,finder);core=None
        try:
            core=importlib.import_module(__package__+'._licensed_entry');_wrap_core(core);core.register()
        except Exception:
            if core:
                try:core.unregister()
                except Exception:pass
            finder.close();_authorized=False;raise
        _core,_finder=core,finder
    _message=_status() if active else 'Licença expirada. Solicite a alteração da validade ao emissor.'
    redraw()
    return active


def activate(code,url):
    if isinstance(code,str) and code.strip().startswith('T2D1.'):
        return apply_receipt(code.strip())
    session=_load_session();url=server_url(url)
    if not isinstance(code,str) or not code.strip().startswith('T2A-'):raise LicenseError('Informe o código de ativação T2A recebido do emissor.')
    code=code.strip()
    # Persist request identity before sending. Lost responses can be retried
    # without creating a second redemption or resetting the start date.
    pending=session.get('pending')
    if not pending or pending.get('code')!=code or session.get('url')!=url:
        session['pending']={'code':code,'request_id':uuid.uuid4().hex,'release_id':_config['release_id']}
    session['url']=url;_save_session()
    response=request(url,'/redeem',sign_request('redeem',session['installation'],session['pending']))
    return apply_receipt(response['receipt'],online=True)


def refresh(url):
    session=_load_session()
    if str(session.get('receipt','')).startswith('T2D1.'):return apply_receipt(session['receipt'])
    url=server_url(url)
    if not session.get('receipt'):raise LicenseError('Ative a instalação antes de atualizar sua licença.')
    claims=json.loads(unb64(session['receipt'].split('.')[1])) if session.get('pending_update') else verify_receipt(session['receipt'],_config,session['installation'])
    response=request(url,'/refresh',sign_request('refresh',session['installation'],{'license_id':claims['license_id'],'request_id':uuid.uuid4().hex,'release_id':_config['release_id']}))
    session['url']=url
    return apply_receipt(response['receipt'],online=True)


def redraw():
    for window in bpy.context.window_manager.windows:
        for area in window.screen.areas:area.tag_redraw()


def auto_activate():
    global _message,_claims,_future,_executor
    if not _registered:return None
    try:
        session=_load_session()
        bpy.context.window_manager.t2_license_server=session.get('url') or _config.get('activation_url','')
        if session.get('receipt'):
            if str(session['receipt']).startswith('T2D1.'):
                apply_receipt(session['receipt'],persist=not state_file().is_file())
                redraw();return None
            if session.get('validated_release')==_config['release_id'] and not session.get('pending_update'):
                apply_receipt(session['receipt'],persist=False)
                redraw();return None
            if session.get('pending_update'):
                hints=json.loads(unb64(session['receipt'].split('.')[1]))
            else:
                hints=verify_receipt(session['receipt'],_config,session['installation'])
            url=server_url(session.get('url') or _config.get('activation_url',''))
            body=sign_request('refresh',session['installation'],{'license_id':hints['license_id'],'request_id':uuid.uuid4().hex,'release_id':_config['release_id']})
            _save_session()
            _message='Validando esta atualização online...'
            if _executor is None:_executor=ThreadPoolExecutor(max_workers=1,thread_name_prefix='Track2License')
            _future=_executor.submit(request,url,'/refresh',body)
            bpy.app.timers.register(finish_validation,first_interval=.1)
    except Exception as exc:_message=str(exc)
    redraw();return None


def finish_validation():
    global _future,_message,_authorized
    if not _registered or _future is None:return None
    if not _future.done():return .1
    try:apply_receipt(_future.result()['receipt'],online=True)
    except Exception as exc:_authorized=False;_message='Validação online recusada: '+str(exc)
    _future=None;redraw();return None


def watchdog():
    if not _registered:return None
    before=_authorized
    if _claims and not _claims['lifetime']:check_access(persist=True)
    if before and not _authorized:
        for name in ('uv_preview','ycd_preview'):
            module=sys.modules.get(__package__+'.'+name)
            if module:
                try:module.stop()
                except Exception:pass
        redraw()
    elif _claims and not _claims['lifetime']:redraw()
    return 30.


class T2L_OT_activate(bpy.types.Operator):
    bl_idname='track2_license.activate';bl_label='Ativar com código de uso único'
    def execute(self,context):
        global _message
        try:
            activate(context.window_manager.t2_license_token,context.window_manager.t2_license_server)
            context.window_manager.t2_license_token='';self.report({'INFO'},_message);return {'FINISHED'}
        except Exception as exc:_message=str(exc);self.report({'ERROR'},str(exc));return {'CANCELLED'}


class T2L_OT_refresh(bpy.types.Operator):
    bl_idname='track2_license.refresh';bl_label='Atualizar licença'
    def execute(self,context):
        global _message
        try:refresh(context.window_manager.t2_license_server);self.report({'INFO'},_message);return {'FINISHED'}
        except Exception as exc:_message=str(exc);self.report({'ERROR'},str(exc));return {'CANCELLED'}


class T2L_PT_license(bpy.types.Panel):
    bl_idname='T2L_PT_license';bl_label='Licença · GTA Track2';bl_space_type='VIEW_3D';bl_region_type='UI';bl_category='GTA Track2';bl_order=-100
    def draw(self,context):
        layout=self.layout;layout.label(text='Versão '+_config['version'])
        layout.label(text=_status(),icon='CHECKMARK' if _authorized else 'LOCKED')
        layout.prop(context.window_manager,'t2_license_server',text='Servidor')
        layout.prop(context.window_manager,'t2_license_token',text='Token normal / Dev')
        layout.operator('track2_license.activate',icon='UNLOCKED')
        if (_claims or (_session and _session.get('pending_update'))) and not (_claims and _claims.get('license_type')=='dev'):
            layout.operator('track2_license.refresh',icon='FILE_REFRESH')
        import textwrap
        box=layout.box()
        for line in textwrap.wrap(_message,48):box.label(text=line)
        if _claims and not _claims['lifetime']:
            remaining=max(0,int(_claims['expires_at']-time.time()))
            days,seconds=divmod(remaining,86400);hours,seconds=divmod(seconds,3600);minutes=seconds//60
            layout.label(text=f'Restam {days}d {hours:02}h {minutes:02}min')
        layout.label(text='Dev: offline lifetime' if _claims and _claims.get('license_type')=='dev' else 'Normal: online na ativação/atualização')


_classes=(T2L_OT_activate,T2L_OT_refresh,T2L_PT_license)


def register():
    global _registered,_receipt_verified,_authorized
    _receipt_verified=False;_authorized=False
    marker=cache_dir()/'license_panel_seen'
    first_open=not marker.is_file() and not any(cache_dir().glob('*.installation'))
    T2L_PT_license.bl_options=set() if first_open else {'DEFAULT_CLOSED'}
    for cls in _classes:bpy.utils.register_class(cls)
    if first_open and not bpy.app.background:
        try:atomic_write(marker,b'1')
        except OSError:pass
    bpy.types.WindowManager.t2_license_token=StringProperty(name='Código de ativação',subtype='PASSWORD',options={'SKIP_SAVE'})
    bpy.types.WindowManager.t2_license_server=StringProperty(name='Servidor de ativação',default=_config.get('activation_url',''),options={'SKIP_SAVE'})
    _registered=True;bpy.app.timers.register(auto_activate,first_interval=.2);bpy.app.timers.register(watchdog,first_interval=30.)
    _github_update.register(__name__, _config['version'])


def unregister():
    global _registered,_core,_finder,_authorized,_receipt_verified,_future,_executor
    _registered=False
    _github_update.unregister()
    for timer in (auto_activate,watchdog,finish_validation):
        if bpy.app.timers.is_registered(timer):bpy.app.timers.unregister(timer)
    if _core:
        workflow=sys.modules.get(__package__+'.file_workflow')
        if workflow and workflow.busy():workflow.cancel_conversion()
        _core.unregister();_core=None
    if _finder:_finder.close();_finder=None
    _authorized=False
    _receipt_verified=False
    if _future:_future.cancel();_future=None
    if _executor:_executor.shutdown(wait=False,cancel_futures=True);_executor=None
    for prop in ('t2_license_token','t2_license_server'):
        if hasattr(bpy.types.WindowManager,prop):delattr(bpy.types.WindowManager,prop)
    for cls in reversed(_classes):bpy.utils.unregister_class(cls)
