# SPDX-License-Identifier: GPL-3.0-or-later
"""GitHub update checks and Blender-managed installation for the licensed add-on."""
import hashlib
import json
from pathlib import Path
import re
import tempfile
from concurrent.futures import ThreadPoolExecutor
import tomllib
from urllib.request import Request, urlopen
from zipfile import ZipFile

import bpy

REPOSITORY = 'Z3R0-B4L4/gta-track2'
API = f'https://api.github.com/repos/{REPOSITORY}'
PACKAGE_ID = 'track2_dual_side'
ARCHIVE = re.compile(r'GTA_Track2_Licenciado_(\d+\.\d+\.\d+)\.zip\Z')
MAX_PACKAGE_SIZE = 32 * 1024 * 1024

_executor = None
_future = None
_offer = None
_download_dir = None
_install_target = None
_installed_version = None
_module = None


def version_tuple(version):
    return tuple(map(int, version.split('.')))


def github_read(path, limit, accept='application/vnd.github+json'):
    request = Request(API + path, headers={'Accept': accept, 'User-Agent': 'GTA-Track2-Blender',
                                         'X-GitHub-Api-Version': '2022-11-28'})
    with urlopen(request, timeout=12) as response:
        if not response.geturl().startswith(API + '/'):
            raise ValueError('Endereço inesperado ao consultar o GitHub.')
        data = response.read(limit + 1)
    if len(data) > limit:
        raise ValueError('Resposta do GitHub maior que o limite esperado.')
    return data


def latest_update(installed, ignored):
    entries = json.loads(github_read('/contents?ref=main', 256 * 1024))
    if not isinstance(entries, list):
        raise ValueError('Lista de arquivos inesperada no GitHub.')
    candidates = []
    for entry in entries:
        name = entry.get('name', '')
        match = ARCHIVE.fullmatch(name)
        size = entry.get('size')
        sha = entry.get('sha', '')
        if not match or entry.get('type') != 'file' or entry.get('path') != name:
            continue
        if not isinstance(size, int) or not 0 < size <= MAX_PACKAGE_SIZE or not re.fullmatch(r'[0-9a-f]{40}', sha):
            continue
        candidates.append((version_tuple(match[1]), match[1], name, sha, size))
    if not candidates:
        return None
    candidate = max(candidates)
    if candidate[0] <= version_tuple(installed) or candidate[1] == ignored:
        return None
    return candidate


def download(offer, path):
    _, version, _, sha, size = offer
    # Read the immutable Git blob that was shown in the dialog.
    data = github_read('/git/blobs/' + sha, size, 'application/vnd.github.raw+json')
    blob_hash = hashlib.sha1(f'blob {len(data)}\0'.encode() + data).hexdigest()
    if len(data) != size or blob_hash != sha:
        raise ValueError('O ZIP baixado não corresponde ao arquivo publicado.')
    path.write_bytes(data)
    with ZipFile(path) as archive:
        prefix = PACKAGE_ID + '/'
        manifest = tomllib.loads(archive.read(prefix + 'blender_manifest.toml').decode('utf-8'))
        release = json.loads(archive.read(prefix + 'release.json'))
        if manifest.get('id') != PACKAGE_ID or manifest.get('version') != version or release.get('version') != version:
            raise ValueError('A versão ou identificação do addon no ZIP é diferente da publicação.')
        payload = archive.read(prefix + 'payload.aes')
        if hashlib.sha256(payload).hexdigest() != release.get('cipher_sha256'):
            raise ValueError('O conteúdo licenciado do ZIP está incompleto.')
    return path


def ignored_path():
    return Path(bpy.utils.user_resource('CONFIG', create=True)) / 'track2_ignored_update.txt'


def ignored_version():
    try:
        return ignored_path().read_text(encoding='utf-8').strip()
    except OSError:
        return ''


def show_status(title, message, icon='INFO'):
    def draw(menu, _context):
        import textwrap
        for line in textwrap.wrap(message, 62):
            menu.layout.label(text=line)
    bpy.context.window_manager.popup_menu(draw, title=title, icon=icon)


def start_check():
    global _future
    if not bpy.context.window_manager or not bpy.context.window_manager.windows:
        return .5
    if bpy.app.online_access:
        _future = _executor.submit(latest_update, _installed_version, ignored_version())
        bpy.app.timers.register(finish_check, first_interval=.25)
    return None


def finish_check():
    global _future, _offer
    if not _future.done():
        return .25
    try:
        _offer = _future.result()
    except Exception as exc:
        print(f'GTA Track2: consulta de atualização indisponível ({exc}).')
    finally:
        _future = None
    if _offer and bpy.context.window_manager.windows:
        window = bpy.context.window_manager.windows[0]
        with bpy.context.temp_override(window=window):
            bpy.ops.track2_update.offer('INVOKE_DEFAULT')
    return None


def install_target():
    parts = _module.split('.')
    if len(parts) != 3 or parts[0] != 'bl_ext' or parts[2] != PACKAGE_ID:
        raise ValueError('Instale o ZIP pelo menu Instalar do Disco para usar a atualização integrada.')
    for repository in bpy.context.preferences.extensions.repos:
        if repository.module == parts[1] and repository.enabled and not repository.use_remote_url:
            return repository.module, Path(repository.directory) / PACKAGE_ID / 'blender_manifest.toml'
    raise ValueError('Instale o ZIP em um repositório local de extensões do Blender.')


def start_download(offer):
    global _future, _download_dir, _install_target
    if _future is not None:
        raise ValueError('Já existe uma atualização em andamento.')
    if not bpy.app.online_access:
        raise ValueError('Ative o acesso online do Blender para baixar a atualização.')
    _install_target = install_target()
    _download_dir = tempfile.TemporaryDirectory(prefix='track2-update-')
    _future = _executor.submit(download, offer, Path(_download_dir.name) / offer[2])
    bpy.app.timers.register(finish_download, first_interval=.25)


def finish_download():
    global _future, _download_dir
    if not _future.done():
        return .25
    folder = _download_dir
    future = _future
    repo, manifest_path = _install_target
    expected_version = _offer[1]
    _future = _download_dir = None
    try:
        path = future.result()
        outcome = bpy.ops.extensions.package_install_files('EXEC_DEFAULT', filepath=str(path),
                                                           repo=repo, enable_on_install=True)
        if 'FINISHED' not in outcome or tomllib.loads(manifest_path.read_text(encoding='utf-8')).get('version') != expected_version:
            raise ValueError('O Blender não confirmou a instalação da nova versão.')
        show_status('GTA Track2 atualizado', f'Versão {expected_version} instalada.', 'CHECKMARK')
    except Exception as exc:
        show_status('Atualização do GTA Track2', str(exc), 'ERROR')
    finally:
        folder.cleanup()
    return None


class T2U_OT_offer(bpy.types.Operator):
    bl_idname = 'track2_update.offer'
    bl_label = 'Atualização do GTA Track2'

    action: bpy.props.EnumProperty(items=[('UPDATE', 'Atualizar', 'Baixar e instalar a versão publicada'),
                                           ('SKIP', 'Não atualizar', 'Continuar na versão atual')], default='SKIP')
    ignore: bpy.props.BoolProperty(name='Não exibir mensagem novamente, até o próximo update')

    @classmethod
    def poll(cls, _context):
        return _offer is not None and _future is None

    def invoke(self, context, _event):
        return context.window_manager.invoke_props_dialog(self, width=450, confirm_text='Confirmar')

    def draw(self, _context):
        self.layout.label(text=f'Versão instalada {_installed_version} · versão disponível {_offer[1]}')
        self.layout.prop(self, 'action', expand=True)
        row = self.layout.row()
        row.enabled = self.action == 'SKIP'
        row.prop(self, 'ignore')

    def execute(self, _context):
        try:
            if self.action == 'UPDATE':
                start_download(_offer)
            elif self.ignore:
                ignored_path().write_text(_offer[1], encoding='utf-8')
        except Exception as exc:
            self.report({'ERROR'}, str(exc))
            return {'CANCELLED'}
        return {'FINISHED'}


def register(module, version):
    global _executor, _installed_version, _module
    _module, _installed_version = module, version
    bpy.utils.register_class(T2U_OT_offer)
    if not bpy.app.background:
        _executor = ThreadPoolExecutor(max_workers=1, thread_name_prefix='Track2Update')
        bpy.app.timers.register(start_check, first_interval=2.)


def unregister():
    global _executor, _future, _download_dir, _offer
    for timer in (start_check, finish_check, finish_download):
        if bpy.app.timers.is_registered(timer):
            bpy.app.timers.unregister(timer)
    if _future and _download_dir:
        folder = _download_dir
        _future.add_done_callback(lambda _result: folder.cleanup())
    if _executor:
        _executor.shutdown(wait=False, cancel_futures=True)
    _executor = _future = _download_dir = _offer = None
    bpy.utils.unregister_class(T2U_OT_offer)
