# SPDX-License-Identifier: GPL-3.0-or-later
"""Import decrypted modules from memory; no cleartext payload files on disk."""
import importlib.abc
import importlib.util
import io
from pathlib import Path
import sys
import zipfile


class MemoryModules(importlib.abc.MetaPathFinder, importlib.abc.Loader):
    def __init__(self, package, folder, plaintext):
        self.package = package
        self.folder = Path(folder)
        self.names = set()
        with zipfile.ZipFile(io.BytesIO(plaintext)) as archive:
            self.sources = {n[:-3]: archive.read(n) for n in archive.namelist() if n.endswith('.py') and '/' not in n}
        if '_licensed_entry' not in self.sources:
            raise ValueError('O pacote não contém o ponto de entrada do addon.')

    def find_spec(self, fullname, path=None, target=None):
        prefix = self.package + '.'
        if fullname.startswith(prefix) and fullname[len(prefix):] in self.sources:
            return importlib.util.spec_from_loader(fullname, self)
        return None

    def create_module(self, spec):
        return None

    def exec_module(self, module):
        name = module.__name__[len(self.package) + 1:]
        module.__file__ = str(self.folder / (name + '.py'))
        module.__package__ = self.package
        self.names.add(module.__name__)
        exec(compile(self.sources[name], module.__file__, 'exec'), module.__dict__)

    def close(self):
        if self in sys.meta_path:
            sys.meta_path.remove(self)
        parent = sys.modules.get(self.package)
        for name in sorted(self.names, key=len, reverse=True):
            child = sys.modules.pop(name, None)
            short = name.rsplit('.', 1)[-1]
            if parent and child is not None and getattr(parent, short, None) is child:
                delattr(parent, short)
        self.names.clear()
        self.sources.clear()
