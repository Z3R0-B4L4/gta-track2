# SPDX-License-Identifier: GPL-3.0-or-later
import ipaddress,json,urllib.request,urllib.error,urllib.parse
from ._license_protocol import LicenseError


def server_url(value):
    parsed=urllib.parse.urlsplit(value.strip())
    if parsed.scheme not in ('https','http') or not parsed.hostname or parsed.username or parsed.password or parsed.query or parsed.fragment or parsed.path not in ('','/'):
        raise LicenseError('Informe apenas o endereço HTTPS do serviço, sem usuário, senha ou caminho.')
    local=parsed.hostname=='localhost'
    try:local=local or ipaddress.ip_address(parsed.hostname).is_loopback
    except ValueError:pass
    if parsed.scheme!='https' and not local:raise LicenseError('HTTP é permitido somente em testes locais. Use HTTPS na VPS.')
    return value.strip().rstrip('/')


class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self,*args,**kwargs):return None


def request(url,route,data=None,admin_token=None):
    address=server_url(url)+route
    headers={'Content-Type':'application/json','Accept':'application/json'}
    if admin_token:headers['Authorization']='Bearer '+admin_token
    req=urllib.request.Request(address,data=None if data is None else json.dumps(data).encode('utf-8'),headers=headers,method='GET' if data is None else 'POST')
    try:
        with urllib.request.build_opener(NoRedirect).open(req,timeout=20) as response:
            raw=response.read(262145)
            if len(raw)>262144:raise LicenseError('Resposta do serviço acima do limite.')
            return json.loads(raw)
    except urllib.error.HTTPError as exc:
        try:message=json.loads(exc.read(8192)).get('detail','Solicitação recusada.')
        except (ValueError,AttributeError):message='Solicitação recusada pelo serviço.'
        raise LicenseError(str(message)) from exc
    except (OSError,urllib.error.URLError,ValueError) as exc:
        raise LicenseError('Não foi possível acessar o serviço de ativação. Confira o endereço e a conexão.') from exc
