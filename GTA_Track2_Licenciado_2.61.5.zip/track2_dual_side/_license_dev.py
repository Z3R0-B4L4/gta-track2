# SPDX-License-Identifier: GPL-3.0-or-later
"""Private Dev tokens and signed per-release AES key envelopes."""
import hashlib,os,re,time
from pathlib import Path
from ._license_protocol import canonical,b64,unb64,key_id,release_aad,LicenseError

DOMAIN=b'Track2 Dev envelopes v1\x00'
SLOTS=range(1,11)


def parse_token(token):
    if not isinstance(token,str) or not re.fullmatch(r'T2D1\.(0[1-9]|10)\.[A-Za-z0-9_-]{43}',token):
        raise LicenseError('Token Dev inválido. Use um dos dez tokens fornecidos pelo emissor.')
    _,slot,encoded=token.split('.');key=unb64(encoded)
    if len(key)!=32:raise LicenseError('Chave do token Dev inválida.')
    return int(slot),key


def validate_set(tokens):
    if not isinstance(tokens,list) or len(tokens)!=10 or len(set(tokens))!=10:
        raise LicenseError('O cofre Dev deve conter exatamente dez tokens diferentes.')
    parsed=[parse_token(token) for token in tokens]
    if [item[0] for item in parsed]!=list(SLOTS) or len({item[1] for item in parsed})!=10:
        raise LicenseError('Os tokens Dev devem ocupar os slots 01 a 10.')
    return tokens


def _used_slots(slots):
    values=list(slots)
    if any(type(slot) is not int or slot not in SLOTS for slot in values):
        raise LicenseError('Use um número de chave Dev entre 01 e 10.')
    return set(values)


def _access_file(vault_dir):
    return Path(vault_dir)/'dev_access.vault'


def predefined_access(vault_dir):
    from ._license_vault import load_vault,save_vault
    path=_access_file(vault_dir)
    if path.is_file():
        access=load_vault(path)
        validate_set(access['dev_tokens'])
        _used_slots(access.get('used_dev_slots',()))
        return access
    # A backed-up release vault also contains the fixed set, so restoring it
    # before building a new release preserves the tokens and their used slots.
    tokens=None
    used=set()
    for candidate in sorted(path.parent.glob('*.vault'),key=lambda p:p.stat().st_mtime,reverse=True):
        if not re.fullmatch(r'\d+\.\d+\.\d+',candidate.stem):continue
        secret=load_vault(candidate)
        if secret.get('dev_tokens'):
            tokens=validate_set(secret['dev_tokens'])
            used=_used_slots(secret.get('used_dev_slots',()))
            break
    if tokens is None:tokens=[f'T2D1.{slot:02d}.'+b64(os.urandom(32)) for slot in SLOTS]
    access={'schema':1,'kind':'dev-access','dev_tokens':tokens,'used_dev_slots':sorted(used)}
    save_vault(path,access)
    return access


def mark_used(vault_dir,slots):
    from ._license_vault import atomic_write,protect
    requested=_used_slots(slots)
    access=predefined_access(vault_dir)
    used=_used_slots(access.get('used_dev_slots',()))|requested
    access['used_dev_slots']=sorted(used)
    atomic_write(_access_file(vault_dir),protect(canonical(access)))
    return access['used_dev_slots']


def release_used_slots(vault_path,secret):
    from ._license_vault import load_vault
    used=_used_slots(secret.get('used_dev_slots',()))
    path=_access_file(Path(vault_path).parent)
    if path.is_file():
        active=load_vault(path)
        if active['dev_tokens']==secret['dev_tokens']:
            used.update(_used_slots(active.get('used_dev_slots',())))
    return used


def envelope_aad(config,slot):return DOMAIN+release_aad(config)+b'\x00'+str(slot).encode('ascii')


def add_envelopes(config,secret,tokens):
    from cryptography.hazmat.primitives.ciphers.aead import AESGCM
    from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
    entries=[]
    used=_used_slots(secret.get('used_dev_slots',()))
    for token in validate_set(tokens):
        slot,key=parse_token(token)
        if slot in used:
            entries.append({'slot':slot,'status':'used'})
            continue
        nonce=os.urandom(12)
        wrapped=AESGCM(key).encrypt(nonce,unb64(secret['aes_key']),envelope_aad(config,slot))
        entries.append({'slot':slot,'token_sha256':hashlib.sha256(token.encode()).hexdigest(),'nonce':b64(nonce),'wrapped_key':b64(wrapped)})
    document={'schema':1,'issued_at':int(time.time()),'entries':entries}
    signature=Ed25519PrivateKey.from_private_bytes(unb64(secret['private_key'])).sign(DOMAIN+release_aad(config)+canonical(document))
    config['dev_access']=dict(document,signature=b64(signature))


def verify_dev(token,config):
    from cryptography.hazmat.primitives.ciphers.aead import AESGCM
    from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey
    from cryptography.exceptions import InvalidSignature,InvalidTag
    slot,key=parse_token(token)
    try:
        document=dict(config['dev_access']);signature=unb64(document.pop('signature'))
        public=unb64(config['public_key'])
        if key_id(public)!=config['key_id']:raise ValueError()
        Ed25519PublicKey.from_public_bytes(public).verify(signature,DOMAIN+release_aad(config)+canonical(document))
        entries=document['entries']
        if document['schema']!=1 or len(entries)!=10 or [e['slot'] for e in entries]!=list(SLOTS):raise ValueError()
        entry=entries[slot-1]
        if entry.get('status')=='used':
            raise LicenseError(f'A chave Dev {slot:02d} já foi utilizada e não permite nova ativação nesta versão.')
        if entry['token_sha256']!=hashlib.sha256(token.encode()).hexdigest():
            raise LicenseError('Este token não é um dos dez tokens Dev desta distribuição.')
        aes=AESGCM(key).decrypt(unb64(entry['nonce']),unb64(entry['wrapped_key']),envelope_aad(config,slot))
        if len(aes)!=32:raise ValueError()
        claims={k:config[k] for k in ('schema','product','version','release_id','key_id')}
        claims.update(license_schema=3,license_type='dev',license_id=hashlib.sha256(('dev:'+token).encode()).hexdigest()[:32],
            dev_slot=slot,activated_at=document['issued_at'],issued_at=document['issued_at'],revision=1,
            aes_key=b64(aes),lifetime=True,validity_days=None,expires_at=None,customer=f'Dev {slot:02d}')
        return claims
    except LicenseError:raise
    except (KeyError,TypeError,ValueError,InvalidSignature,InvalidTag) as exc:
        raise LicenseError('Token Dev ou autorização desta versão inválido/alterado.') from exc


def export_tokens(vault_path,destination):
    from ._license_vault import load_vault,atomic_write
    secret=load_vault(vault_path);tokens=validate_set(secret.get('dev_tokens'))
    used=release_used_slots(vault_path,secret)
    text='TRACK2 — TOKENS DEV PRIVADOS\nLifetime · offline · sem HWID/UUID\nNão publicar no GitHub nem distribuir com o addon.\n\n'
    text+='\n'.join(f'{slot:02d}: '+('Utilizada' if slot in used else token) for slot,token in enumerate(tokens,1))+'\n'
    atomic_write(destination,text.encode('utf-8'))
    return {'count':len(tokens)-len(used),'used_slots':sorted(used),'token_file':str(destination),'version':secret['version']}
